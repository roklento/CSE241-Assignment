#ifndef match_h
#define match_h

#include <iostream>
#include <string>
#include "class.h"

/*Declaring the functions that will be used in the match.cpp file.*/
void match(Robot*,Robot*);

#endif
