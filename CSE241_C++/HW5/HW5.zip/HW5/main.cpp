#include "circuit.h"

using namespace std;

int main()
{
    circuit circuit;
}